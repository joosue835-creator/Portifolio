import { ProjectCard } from "./project-card"

const projects = [
  {
    title: "E-commerce Moderno",
    description: "Loja virtual completa com carrinho de compras, pagamentos integrados e painel administrativo.",
    image: "/projects/ecommerce.jpg",
    link: "https://exemplo.com/ecommerce",
  },
  {
    title: "Dashboard Analytics",
    description: "Painel de métricas em tempo real com gráficos interativos e relatórios personalizados.",
    image: "/projects/dashboard.jpg",
    link: "https://exemplo.com/dashboard",
  },
  {
    title: "App de Finanças",
    description: "Aplicação para controle financeiro pessoal com metas, categorias e visualizações.",
    image: "/projects/finance.jpg",
    link: "https://exemplo.com/finance",
  },
  {
    title: "Landing Page SaaS",
    description: "Página de conversão otimizada para startup de tecnologia com design premium.",
    image: "/projects/saas.jpg",
    link: "https://exemplo.com/saas",
  },
  {
    title: "Blog Corporativo",
    description: "Sistema de blog com CMS integrado, SEO otimizado e design responsivo.",
    image: "/projects/blog.jpg",
    link: "https://exemplo.com/blog",
  },
  {
    title: "Plataforma Educacional",
    description: "Sistema de cursos online com área de membros, certificados e gamificação.",
    image: "/projects/education.jpg",
    link: "https://exemplo.com/education",
  },
]

export function Projects() {
  return (
    <section id="projetos" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-wider uppercase text-sm mb-4">
            Portfólio
          </p>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Projetos em Destaque
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Uma seleção dos meus trabalhos mais recentes. Cada projeto é único e desenvolvido 
            com atenção aos detalhes e foco na experiência do usuário.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <ProjectCard key={project.title} {...project} />
          ))}
        </div>
      </div>
    </section>
  )
}
